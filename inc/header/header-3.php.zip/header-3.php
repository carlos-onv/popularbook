<?php
/**
 * @name : Default
 * @package : CMSSuperHeroes
 * @author : Kenji
 */

?>
<div id="cshero-header" class="header-3">

	<?php book_junky_header_3_top(); ?>
	<div class="wrap-middler">
	    <div class="container">

	        <div class="row">

	            <div class="col-xs-12 col-md-5 col-lg-5 top-left-3">

	                <?php book_junky_header_3_logo(); ?>

	                <a href="#" class="menu"><i class="fa fa-bars"></i> <?php echo esc_html__('Menu', 'book-junky'); ?></a>
	            </div><!-- col-4-logo -->
	             
	            <div class="col-xs-12 col-md-7 col-lg-7 top-right-3">
	                <!--cut-->
	               	
					<!--cut-->
					
					<div class="wrap-free-shipping clearfix">
                            <!--<img src="<?php echo get_template_directory_uri(); ?>/assets/images/free_shipping_minimum50.png" />-->
                            <img src="https://www.popularbook.ca/wp-content/uploads/free_shipping_70.png" />
                        </div> 
                        
                        <div class="eCatalogue clearfix">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/icon-1.png" />
                            <div class="content">
                                <a href="https://www.popularbook.ca/wp-content/uploads/PBCcatalogue2023-compressed.pdf" target="_blank">
                                    <h5><?php esc_html_e('eCatalogue', ''); ?></h5>
                                </a>
                            </div>
                        </div>
                     
                        <div class="wrap-book-shelf clearfix">
                            <img src="<?php echo get_template_directory_uri() . '/assets/images/icon-1.png'; ?>"
                                 alt="<?php esc_html_e('icon 1', 'book-junky'); ?>">
                            <div class="content">
                                <?php if (class_exists('WooCommerce')) : ?>
                                    <a href="<?php echo wc_get_account_endpoint_url('book-shelf'); ?>"
                                   alt="<?php esc_html_e('My Account', 'book-junky'); ?>">
                                <?php endif; ?>
                                <h5><?php esc_html_e('Wishlist', 'book-junky'); ?></h5>
                                <?php if (class_exists('WooCommerce')) : ?>
                                </a>
                                <?php endif; ?>
                                <span class="aj-count">
                                    <?php
                                    $current_uid = get_current_user_id();

                                    $count = flex_favorites_get_bookshelf_count_of_user($current_uid);

                                    echo flex_favorites_get_bookshelf_count_of_user_display($count);
                                    ?>
                                </span>
                            </div>
                        </div>
                        <div class="wrap-your-basket clearfix">
                            <img src="<?php echo get_template_directory_uri() . '/assets/images/icon-2.png'; ?>"
                                 alt="<?php esc_html_e('icon 2', 'book-junky'); ?>">
                            <div class="content">
                                <h5>
                                    <?php if (class_exists('WooCommerce')) : ?>
                                    <a href="<?php echo get_permalink(get_option('woocommerce_cart_page_id')); ?>">
                                        <?php endif; ?>

                                        <?php esc_html_e('Your Basket', 'book-junky'); ?>
                                        <?php if (class_exists('WooCommerce')) : ?>
                                    </a>
                                    <?php endif; ?>
                                </h5>
                                <?php if (class_exists('WooCommerce')) : ?>
                                <span>
                                    <?php
                                    if (!WC()->cart->is_empty()) :
    
                                        echo WC()->cart->get_cart_subtotal();
                                    else :
    
                                        echo "0.00";
                                    endif;
                                    ?>
                                </span>
                                <?php else: ?>

                                    <span>

                                    <?php echo "0.00"; ?>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div><!--EO basket-->
					
	            </div><!-- col-6-search -->
	             
	            
				
	        </div><!-- row -->
	    </div><!-- #container -->
    </div><!-- wrap-middler -->

    <div class="container">
		
		<!--MJ-->
		<div class="row top-nav">
			<div id="top-navigation" class="col-xs-12 ">

                <nav id="site-navigation" class="main-navigation">
                    <?php header_top_navigation(); ?>
                </nav>
            </div>
		</div>
		<!--MJ-->
		
    	<div class="row">
    		<div id="header-navigation" class="col-xs-12 <?php book_junky_header_class('cshero-main-header'); ?>">

                <nav id="site-navigation" class="main-navigation">

                    <?php book_junky_header_navigation(); ?>
                </nav>
            </div>
    	</div>
    </div>
</div><!-- #site-navigation -->


